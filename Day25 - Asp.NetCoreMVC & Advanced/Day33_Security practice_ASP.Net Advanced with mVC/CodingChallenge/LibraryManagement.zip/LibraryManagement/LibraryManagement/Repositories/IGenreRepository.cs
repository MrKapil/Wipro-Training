using LibraryManagement.Models;

namespace LibraryManagement.Repositories
{
    public interface IGenreRepository : IRepository<Genre> { }

    
}
