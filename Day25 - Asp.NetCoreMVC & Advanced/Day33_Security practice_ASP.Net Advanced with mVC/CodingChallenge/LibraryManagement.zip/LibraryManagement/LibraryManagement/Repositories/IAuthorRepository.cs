using LibraryManagement.Models;

namespace LibraryManagement.Repositories
{
    public interface IAuthorRepository : IRepository<Author> { }

    
}
