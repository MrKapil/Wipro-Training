﻿document.getElementById('ping').addEventListener('click', function () {
    document.getElementById('result').textContent = 'JS loaded and working!';
});

