namespace AuthenticationManagemant.Configurations
{
    public class EmailConfiguration
    {
        public static string SenderEmail = "noreply.testpk@gmail.com";
        public static string Password = "test123/";
        public static string Host = "smtp.gmail.com";
        public static int Port = 465;
        public static bool UseSsl = true;
        public static string DisplayName = "MVC Support";
    }
}