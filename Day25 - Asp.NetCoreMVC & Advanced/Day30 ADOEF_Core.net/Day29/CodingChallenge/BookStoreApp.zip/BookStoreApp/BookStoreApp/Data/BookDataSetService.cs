﻿namespace BookStoreApp.Data
{
    public class BookDataSetService
    {
    }
}
