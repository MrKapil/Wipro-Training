﻿namespace BookStoreApp.Data
{
    public class IBookDataSetService
    {
    }
}
